import boto3

# Create an S3 client
s3 = boto.client('s3')


response = s3.create_bucket(ACL='public-read',
                            Bucket='servicemonitor',
                            location





# Create the configuration for the website
website_configuration = {
    'ErrorDocument': {'Key': 'error.html'},
    'IndexDocument': {'Suffix': 'index.html'},
}

# Set the new policy on the selected bucket
s3.put_bucket_website(
    Bucket='servicemonitor',
    WebsiteConfiguration=website_configuration
)
