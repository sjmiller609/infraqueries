(function() {


}).call(this);

 //# sourceMappingURL=vm-animation.js.map