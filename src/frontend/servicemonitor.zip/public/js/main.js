(function() {
  var CallMethod, loadVms, root, vms;

  vms = [];

  CallMethod = function() {
    return $.getJSON('http://flask-env.bxaftkmkem.us-west-2.elasticbeanstalk.com//state', {
      access_key: "0000",
      secret_key: "0000"
    }, function(data) {
      return vms = data;
    });
  };

  loadVms = function() {
    CallMethod();
    return setTimeout(function() {
      var az, cloudShape, i, len, name, newVM, newVMContent, results, vm, vmString;
      $(".cloud-container").empty();
      cloudShape = $("<div>");
      cloudShape.addClass("cloud-shape");
      $(".cloud-container").append(cloudShape);
      results = [];
      for (i = 0, len = vms.length; i < len; i++) {
        vm = vms[i];
        vmString = JSON.stringify(vm);
        az = vm.az;
        name = vm.name;
        newVM = $("<div>");
        newVM.addClass("vm-container");
        newVMContent = $("<div onclick=vmClick(\'" + vmString + "\')>");
        newVMContent.addClass("vm");
        newVMContent.addClass("vm-text");
        newVMContent.text(az + ", " + name);
        newVM.append(newVMContent);
        $(".cloud-container").append(newVM);
        results.push(console.log("cloud updated"));
      }
      return results;
    }, 1000);
  };

  root = typeof exports !== "undefined" && exports !== null ? exports : this;

  root.vmClick = function(vm) {
    $(".modal").show();
    return $(".vm-name").text(vm);
  };

  $(document).ready(function() {
    loadVms();
    return setInterval(function() {
      return loadVms();
    }, 10000);
  });

}).call(this);

 //# sourceMappingURL=main.js.map